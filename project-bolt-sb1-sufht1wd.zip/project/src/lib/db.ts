import type {
  Question,
  QuestionBank,
  Profile,
  Snapshot,
  ProgressEntry,
  ModuleId,
} from './types';
import { PASSING_SCORE } from './types';

const DB_NAME = 'calistung-db';
const DB_VERSION = 1;

const STORES = {
  META: 'meta',
  QUESTIONS: 'questions',
  PROFILES: 'profiles',
  PROGRESS: 'progress',
  SNAPSHOTS: 'snapshots',
} as const;

type StoreName = (typeof STORES)[keyof typeof STORES];

let dbPromise: Promise<IDBDatabase> | null = null;

function openDB(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORES.META)) {
        db.createObjectStore(STORES.META);
      }
      if (!db.objectStoreNames.contains(STORES.QUESTIONS)) {
        db.createObjectStore(STORES.QUESTIONS, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORES.PROFILES)) {
        db.createObjectStore(STORES.PROFILES, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORES.PROGRESS)) {
        db.createObjectStore(STORES.PROGRESS, { keyPath: 'profileId' });
      }
      if (!db.objectStoreNames.contains(STORES.SNAPSHOTS)) {
        db.createObjectStore(STORES.SNAPSHOTS, { keyPath: 'id' });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return dbPromise;
}

async function tx<T>(
  store: StoreName,
  mode: IDBTransactionMode,
  fn: (s: IDBObjectStore) => IDBRequest<T>
): Promise<T> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const t = db.transaction(store, mode);
    const req = fn(t.objectStore(store));
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function txAll<T>(
  store: StoreName,
  mode: IDBTransactionMode,
  fn: (s: IDBObjectStore) => IDBRequest<T[]>
): Promise<T[]> {
  const result = await tx(store, mode, fn);
  return result ?? [];
}

async function getAll<T>(store: StoreName): Promise<T[]> {
  return txAll(store, 'readonly', (s) => s.getAll() as IDBRequest<T[]>);
}

async function getOne<T>(store: StoreName, key: string): Promise<T | undefined> {
  return tx(store, 'readonly', (s) => s.get(key) as IDBRequest<T>);
}

async function put<T>(store: StoreName, value: T): Promise<void> {
  await tx(store, 'readwrite', (s) => s.put(value as unknown as object));
}

async function putAll<T>(store: StoreName, values: T[]): Promise<void> {
  const db = await openDB();
  await new Promise<void>((resolve, reject) => {
    const t = db.transaction(store, 'readwrite');
    const s = t.objectStore(store);
    for (const v of values) s.put(v as unknown as object);
    t.oncomplete = () => resolve();
    t.onerror = () => reject(t.error);
  });
}

async function del(store: StoreName, key: string): Promise<void> {
  await tx(store, 'readwrite', (s) => s.delete(key));
}

async function clearStore(store: StoreName): Promise<void> {
  await tx(store, 'readwrite', (s) => s.clear());
}

// ---- Meta ----

async function getMeta<T>(key: string): Promise<T | undefined> {
  return tx(STORES.META, 'readonly', (s) => s.get(key) as IDBRequest<T>);
}

async function setMeta<T>(key: string, value: T): Promise<void> {
  await tx(STORES.META, 'readwrite', (s) => s.put(value as unknown as object, key));
}

// ---- Questions ----

export async function getAllQuestions(): Promise<Question[]> {
  return getAll<Question>(STORES.QUESTIONS);
}

export async function putQuestions(questions: Question[]): Promise<void> {
  await putAll(STORES.QUESTIONS, questions);
}

export async function replaceAllQuestions(questions: Question[]): Promise<void> {
  await clearStore(STORES.QUESTIONS);
  await putAll(STORES.QUESTIONS, questions);
}

export async function getQuestionBank(): Promise<QuestionBank> {
  const [questions, version, updatedAt] = await Promise.all([
    getAllQuestions(),
    getMeta<number>('questionVersion').then((v) => v ?? 1),
    getMeta<string>('questionUpdatedAt').then((v) => v ?? new Date().toISOString()),
  ]);
  return { version, updated_at: updatedAt, questions };
}

export async function setQuestionBankMeta(version: number): Promise<void> {
  await setMeta('questionVersion', version);
  await setMeta('questionUpdatedAt', new Date().toISOString());
}

// ---- Profiles ----

export async function getAllProfiles(): Promise<Profile[]> {
  return getAll<Profile>(STORES.PROFILES);
}

export async function getProfile(id: string): Promise<Profile | undefined> {
  return getOne<Profile>(STORES.PROFILES, id);
}

export async function saveProfile(profile: Profile): Promise<void> {
  await put(STORES.PROFILES, profile);
}

export async function deleteProfile(id: string): Promise<void> {
  await del(STORES.PROFILES, id);
  await del(STORES.PROGRESS, id);
}

// ---- Progress ----

export async function getProfileProgress(
  profileId: string
): Promise<ProgressEntry[]> {
  const record = await getOne<{ profileId: string; entries: ProgressEntry[] }>(
    STORES.PROGRESS,
    profileId
  );
  return record?.entries ?? [];
}

export async function addProgressEntry(
  profileId: string,
  entry: ProgressEntry
): Promise<void> {
  const existing = await getProfileProgress(profileId);
  const record = { profileId, entries: [...existing, entry] };
  await put(STORES.PROGRESS, record);
}

const MODULE_IDS: ModuleId[] = ['membaca', 'menulis', 'berhitung'];

export async function getUnlockedKeys(profileId: string): Promise<string[]> {
  const progress = await getProfileProgress(profileId);
  const unlocked = new Set<string>();
  MODULE_IDS.forEach((m) => unlocked.add(`${m}:1:1`));
  const bestScore = new Map<string, number>();
  for (const p of progress) {
    const key = `${p.modul}:${p.kelas}:${p.level}`;
    const prev = bestScore.get(key) ?? 0;
    bestScore.set(key, Math.max(prev, p.nilai));
  }
  for (const [key, score] of bestScore) {
    if (score < PASSING_SCORE) continue;
    const [modul, kelasStr, levelStr] = key.split(':');
    const kelas = parseInt(kelasStr);
    const level = parseInt(levelStr);
    const nextLevel = level + 1;
    if (nextLevel <= 5) {
      unlocked.add(`${modul}:${kelas}:${nextLevel}`);
    } else if (kelas < 5) {
      unlocked.add(`${modul}:${kelas + 1}:1`);
    }
  }
  return Array.from(unlocked);
}

// ---- Snapshots ----

export async function createSnapshot(bank: QuestionBank): Promise<Snapshot> {
  const snapshot: Snapshot = {
    id: crypto.randomUUID(),
    created_at: new Date().toISOString(),
    data: bank,
  };
  await put(STORES.SNAPSHOTS, snapshot);
  return snapshot;
}

export async function getAllSnapshots(): Promise<Snapshot[]> {
  return getAll<Snapshot>(STORES.SNAPSHOTS);
}

export async function deleteSnapshot(id: string): Promise<void> {
  await del(STORES.SNAPSHOTS, id);
}

// ---- Export / Import ----

export interface ExportData {
  profiles: Profile[];
  progress: { profileId: string; entries: ProgressEntry[] }[];
  questions: Question[];
  snapshots: Snapshot[];
  exported_at: string;
}

export async function exportAllData(): Promise<ExportData> {
  const [profiles, questions, snapshots, progressRecords] = await Promise.all([
    getAllProfiles(),
    getAllQuestions(),
    getAllSnapshots(),
    getAll<{ profileId: string; entries: ProgressEntry[] }>(STORES.PROGRESS),
  ]);
  return {
    profiles,
    progress: progressRecords,
    questions,
    snapshots,
    exported_at: new Date().toISOString(),
  };
}

export async function importAllData(data: ExportData): Promise<void> {
  await clearStore(STORES.PROFILES);
  await clearStore(STORES.PROGRESS);
  await clearStore(STORES.QUESTIONS);
  await clearStore(STORES.SNAPSHOTS);
  if (data.profiles) await putAll(STORES.PROFILES, data.profiles);
  if (data.progress) await putAll(STORES.PROGRESS, data.progress);
  if (data.questions) await putAll(STORES.QUESTIONS, data.questions);
  if (data.snapshots) await putAll(STORES.SNAPSHOTS, data.snapshots);
}

export type { ProgressEntry } from './types';
