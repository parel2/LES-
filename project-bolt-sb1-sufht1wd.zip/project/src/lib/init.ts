import { SEED_QUESTIONS } from './seed';
import { getAllQuestions, putQuestions } from './db';

const SEED_VERSION = 2;

export async function ensureSeedData(): Promise<void> {
  const existing = await getAllQuestions();
  if (existing.length === 0) {
    await putQuestions(SEED_QUESTIONS);
    localStorage.setItem('seedVersion', String(SEED_VERSION));
    return;
  }
  const storedVersion = parseInt(localStorage.getItem('seedVersion') ?? '0', 10);
  if (storedVersion < SEED_VERSION) {
    const seedIds = new Set(SEED_QUESTIONS.map((q) => q.id));
    const nonSeed = existing.filter((q) => !seedIds.has(q.id));
    await putQuestions([...nonSeed, ...SEED_QUESTIONS]);
    localStorage.setItem('seedVersion', String(SEED_VERSION));
  }
}
