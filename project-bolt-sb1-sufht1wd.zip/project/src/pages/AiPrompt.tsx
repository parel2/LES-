import { useState } from 'react';
import { Check, Copy, FileJson, Lightbulb } from 'lucide-react';
import { TopBar } from '@/components/TopBar';

const PROMPT = `Kamu adalah pembuat soal calistung untuk murid SD kelas 1-5.

TUGAS:
Ubah materi mentah yang saya berikan menjadi JSON array berisi soal latihan. Jangan menulis penjelasan di luar JSON.

ATURAN:
1. Gunakan modul tepat: "membaca", "menulis", atau "berhitung".
2. Gunakan kelas dan level berupa angka 1 sampai 5. Level harus sesuai tingkat kesulitan kelas.
3. Gunakan tipe_soal tepat: "pilihan_ganda", "isian", "menyalin", atau "pemahaman".
4. Setiap soal wajib punya: modul, kelas, level, tipe_soal, pertanyaan, jawaban_benar.
5. Untuk pilihan_ganda, wajib ada pilihan berupa array berisi 4 string. jawaban_benar harus sama persis dengan salah satu pilihan.
6. Untuk pemahaman, tambahkan teks_bacaan sebelum pertanyaan.
7. Untuk menulis, gunakan kata_kunci berupa array jawaban yang bisa diterima jika diperlukan.
8. Tambahkan penjelasan singkat untuk membantu guru menjelaskan jawaban.
9. Buat soal yang ramah anak, jelas, dan sesuai murid SD (bukan TK).
10. Jangan gunakan code fence markdown. Keluarkan JSON murni yang bisa langsung ditempel ke aplikasi.

CONTOH FORMAT:
[
  {
    "modul": "berhitung",
    "kelas": 3,
    "level": 2,
    "tipe_soal": "pilihan_ganda",
    "pertanyaan": "Berapakah hasil dari 24 + 18?",
    "pilihan": ["32", "42", "44", "40"],
    "jawaban_benar": "42",
    "penjelasan": "24 + 18 = 42"
  },
  {
    "modul": "membaca",
    "kelas": 2,
    "level": 1,
    "tipe_soal": "pemahaman",
    "teks_bacaan": "Siti merawat bunga di halaman rumah.",
    "pertanyaan": "Apa yang dirawat Siti?",
    "pilihan": ["Bunga", "Kucing", "Sepeda", "Buku"],
    "jawaban_benar": "Bunga",
    "penjelasan": "Teks menyebutkan Siti merawat bunga."
  }
]

MATERI MENTAH DARI GURU:
[Tempelkan materi di sini]

Buat 5-10 soal dari materi tersebut.`;

export function AiPrompt() {
  const [copied, setCopied] = useState(false);
  async function copy() { await navigator.clipboard.writeText(PROMPT); setCopied(true); setTimeout(() => setCopied(false), 2000); }
  return <div className="min-h-screen bg-slate-50"><TopBar title="Prompt AI untuk Guru" back teacher /><main className="max-w-4xl mx-auto px-4 sm:px-6 py-7"><div className="max-w-2xl mb-6"><p className="text-sm font-bold text-amber-600 uppercase tracking-wide">Bantuan membuat materi</p><h1 className="text-3xl font-black text-slate-800 mt-1">Prompt AI siap pakai</h1><p className="text-slate-500 mt-2">Salin template ini ke ChatGPT, Claude, atau AI lain bersama materi pelajaranmu.</p></div><div className="grid lg:grid-cols-[1fr_280px] gap-5"><section className="bg-slate-900 rounded-2xl overflow-hidden shadow-lg"><div className="px-5 py-3 bg-slate-800 flex items-center justify-between"><div className="flex items-center gap-2 text-slate-200 font-bold text-sm"><FileJson className="w-4 h-4 text-amber-400" /> Template prompt</div><button onClick={copy} className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/10 text-white text-xs font-bold hover:bg-white/20">{copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}{copied ? 'Tersalin' : 'Salin prompt'}</button></div><pre className="p-5 text-xs sm:text-sm text-slate-300 leading-relaxed whitespace-pre-wrap overflow-auto max-h-[620px]">{PROMPT}</pre></section><aside className="space-y-4"><div className="bg-amber-50 border border-amber-200 rounded-2xl p-5"><Lightbulb className="w-6 h-6 text-amber-500 mb-3" /><h2 className="font-black text-amber-900">Cara menggunakan</h2><ol className="mt-3 space-y-3 text-sm text-amber-800"><li><b>1.</b> Salin prompt di samping.</li><li><b>2.</b> Tempel ke chatbot AI pilihanmu.</li><li><b>3.</b> Ganti bagian materi mentah dengan materi pelajaran.</li><li><b>4.</b> Salin hasil JSON dari AI.</li><li><b>5.</b> Tempel di halaman Drop Soal.</li></ol></div><div className="bg-white border border-slate-200 rounded-2xl p-5"><h2 className="font-black text-slate-800">Tips untuk guru</h2><p className="text-sm text-slate-500 mt-2 leading-relaxed">Sebutkan kelas, topik, dan tingkat kesulitan yang diinginkan di bagian materi agar soal yang dibuat lebih sesuai.</p></div></aside></div></main></div>;
}
